<?php $rand=(rand(1,2)); ?>
<html>
  <head>
    <title>Simple Map</title>
    <link rel="stylesheet" type="text/css" href="./style.css" />
    
    <meta charset="utf-8">

    <style type="text/css">
    .defibox{background-color:#fff ;display: flex;justify-content: space-between; border-radius: 50px;}
    .minimap{padding-left:50px ;padding: 20px; display: flex;flex-direction: column;}
    .textdefi{display: flex;justify-content: space-between;width: 80%;}
    .adresse{font-family: 'Archivo', sans-serif;
font-style: normal;
font-size: 15px;

color: #000000;}
    .desc {font-family: 'Impact';
font-style: normal;
font-size: 50px;

color: #000000;}
h3{color: rgba(0, 0, 0, 0.5); font-family: 'Archivo', sans-serif;font-size: 60px;color: #fff;}
h4{color: rgba(0, 0, 0, 0.5); font-family: 'Archivo', sans-serif;font-size: 20px;color: #fff;}









a{text-decoration: none;}

<?php  if($rand==2){?>

               body{background: rgb(0,104,255);
            background: linear-gradient(65deg, rgba(0,104,255,1) 60%, rgba(0,232,255,1) 100%, rgba(0,104,255,1) 100%);
            }.PP{content:url(femmePP.png);width: 290px;height: 250px}
            p,h1{background: #0068ff;
                background: linear-gradient(to right, #0068ff 0%, #00E8FF 100%);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;}
}


            <?php }else{?>

               body{background: rgb(255,252,0);
               background: linear-gradient(-150deg, rgba(255,252,0,1) 0%, rgba(255,0,232,1) 100%);}
               .PP{content:url(hommePP.png);width: 290px;height: 250px} p,h1{background: #FF00C3;
background: linear-gradient(to right, #FF00C3 0%, #FFD500 100%);
-webkit-background-clip: text;
-webkit-text-fill-color: transparent;
}
}
                <?php }?>



  </style>
  <style type="text/css">   
                @media screen and (max-width: 900px){
                  .score{font-family: 'Impact';
font-style: normal;
font-size: 10vw;margin: 20px;}iframe {

  width: 80%;
}.minimap{width: 80%;}} @media screen and (min-width: 900px){
  .score{font-family: 'Impact';
font-style: normal;
font-size: 5vw;
margin-right: 20%;color: #000;}iframe {

  width: 100%;
}.minimap{width: 100%;}}
</style>

  </head>
   <body>
    <?php include("nav.php"); ?>
    <h3 align="center">Les Aventures rien que pour vous*</h3>
    <h4 align="center">*(Tous les joueurs ont les mêmes missions alors foncez et prenez leurs place)</h4>
    
    <?php
$bdd = new PDO("mysql:host=localhost;dbname=maps_valence;charset=utf8", "root", "");
$req = $bdd->query('SELECT * FROM reward');
while ($result = $req->fetch()) {
?><a href="mission.php?id=<?=$result['id']?>"><div class="radiant"><div class="defibox">
   <div class="minimap" id="minimap"><?=$result['map']; ?></div>


 <div class="textdefi">
    <div class="outer-container">
    <div class="top-section">
      <p class="desc" id="score"><?=$result['adresse']; ?></p>
    </div>
    <div class="bottom-section">

<p class="adresse" id="score"><?=$result['description']; ?></p>
      </div>
    </div>
  </div>
    <div class="descadresse"><div class="test"></p></div></div>
    <h1 class="score" >+<?=$result['points']; ?><br>Points</h1></div></div></a>
<br><br><br><br><br>

<?php }?>

</body>
  </body>
</html>