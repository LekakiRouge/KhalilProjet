<?php
session_start();
 
$bdd = new PDO('mysql:host=127.0.0.1;dbname=maps_valence', 'root', '');
 
if(isset($_POST['formconnexion'])) {
   $mailconnect = htmlspecialchars($_POST['mailconnect']);
   $mdpconnect = htmlspecialchars($_POST['mdpconnect']);
   if(!empty($mailconnect) AND !empty($mdpconnect)) {
      $requser = $bdd->prepare("SELECT * FROM membres WHERE mail = ? AND motdepasse = ?");
      $requser->execute(array($mailconnect, $mdpconnect));
      $userexist = $requser->rowCount();
      if($userexist == 1) {
         $userinfo = $requser->fetch();
         $_SESSION['id'] = $userinfo['id'];
         $_SESSION['pseudo'] = $userinfo['pseudo'];
         $_SESSION['mail'] = $userinfo['mail'];
         header("Location: profil.php?id=".$_SESSION['id']);
      } else {
         $erreur = "Mauvais mail ou mot de passe !";
      }
   } else {
      $erreur = "Tous les champs doivent être complétés !";
   }
}
?>
<html>
   <head>
      <title>TUTO PHP</title>
      <meta charset="utf-8">
      <link href="https://fonts.googleapis.com/css?family=Archivo:500|Open+Sans:300,700" rel="stylesheet">
                  <style type="text/css">  

                     @media screen and (max-width: 1250px){
                     input{border-width: 0px;border-bottom-width: 3px;border-color: #ffffff;margin: 1.80rem; padding-left: 2rem;width: 70%;height: 30px;font-size: 30px; background: none;display: flex;color: #ffffff}
            input[name="formconnexion"] {background: linear-gradient(90deg, rgba(46,0,255,1) 0%, rgba(255,0,254,1) 100%);border: none;border-radius: 15px;margin: 15px;position: relative:font-size: 40px;}
            body{background: rgb(0,104,255);
            background: linear-gradient(90deg, rgba(0,104,255,1) 0%, rgba(0,232,255,1) 100%, rgba(255,255,255,1) 100%);
            display: grid;justify-content: center;align-items: center;}
            img{width: 60%;margin-bottom: 50px;}
            h2{color: #fff; font-family: 'Archivo', sans-serif;font-size: 40px;}
            h3{color: #fff; font-family: 'Archivo', sans-serif;font-size: 30px;}
}
                     @media screen and (min-width: 1250px){
                     input{border-width: 0px;border-bottom-width: 3px;border-color: #ffffff;margin: 1.80rem; padding-left: 2rem;width: 500px;height: 50px;font-size: 30px; background: none;display: flex;color: #ffffff}
            input[name="formconnexion"] {background: linear-gradient(90deg, rgba(46,0,255,1) 0%, rgba(255,0,254,1) 100%);;border: none;border-radius: 15px;margin: 15px;position: relative:font-size: 40px;}
            body{background: rgb(255,252,0);
background: linear-gradient(90deg, rgba(255,252,0,1) 0%, rgba(255,0,232,1) 100%);
            position: absolute;left: 15%;top: 20%;}
            img{position: absolute;left: 40vw;top: 10%;width: 100%;}
            h2{color: #fff; font-family: 'Archivo', sans-serif;font-size: 65px;}
            h3{color: #fff; font-family: 'Archivo', sans-serif;font-size: 40px;}
}
            



</style>

   </head>
   <body>

      <div class="all" align="center">
         <img src="connexion.png">
         <h2>Connexion</h2>
         <h3>Tu nous avais manqué! Bon retour parmis nous</h3>
         <br /><br />
         <form method="POST" action="">
            <input type="email" name="mailconnect" placeholder="Mail" /><br /><br />
            <input type="password" name="mdpconnect" placeholder="Mot de passe" />
            <br /><br />
            <input type="submit" name="formconnexion" value="Se connecter !" align="center" />
         </form>
         <?php
         if(isset($erreur)) {
            echo '<font color="red">'.$erreur."</font>";
         }
         ?>

      </div>




   </body>
</html>