<?php $rand=(rand(1,2)); ?>
<html>
  <head>
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">    <title>Simple Map</title>
    
    
    <meta charset="utf-8">

    <style type="text/css">

      .main-content  h4{color: initial;}
               
          
}}
      .containertest > h4{color: #fff, !important}
    .defibox{background-color:#fff ;display: flex;justify-content: space-between; border-radius: 50px;}
    .minimap{padding-left:50px ;padding: 20px; display: flex;flex-direction: column;}
    .textdefi{display: flex;justify-content: space-between;width: 80%;}
    .adresse{font-family: 'Archivo', sans-serif;
font-style: normal;
font-size: 15px;

color: #fff;}
    .desc {font-family: 'Impact';
font-style: normal;
font-size: 50px;

color: #fff;}
h3{color: rgba(0, 0, 0, 0.5); font-family: 'Archivo', sans-serif;font-size: 60px;color: #fff;}
h4{color: rgba(0, 0, 0, 0.5); font-family: 'Archivo', sans-serif;font-size: 20px;color: #fff;}









a{text-decoration: none;}

<?php  if($rand==2){?>
  .containertest{background: linear-gradient(-150deg, rgba(255,252,0,1) 0%, rgba(255,0,232,1) 100%);width: 100%;}
p{font-family:'Impact';color: #fff;}
               .PP{content:url(femmePP.png);width: 290px;height: 250px}
            p,h1{background: #0068ff;
                background: linear-gradient(to right, #0068ff 0%, #00E8FF 100%);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;}
}


            <?php }else{?>
.containertest{background: rgb(0,104,255);
            background: linear-gradient(65deg, rgba(0,104,255,1) 60%, rgba(0,232,255,1) 100%, rgba(0,104,255,1) 100%);width: 100%;
            }
               
               .PP{content:url(hommePP.png);width: 290px;height: 250px} p,h1{background: #FF00C3;
background: linear-gradient(to right, #FF00C3 0%, #FFD500 100%);
-webkit-background-clip: text;
-webkit-text-fill-color: transparent;
}
}
                <?php }?>



  </style>
  <style type="text/css">   
                @media screen and (max-width: 900px){
                  .score{font-family: 'Impact';
font-style: normal;
font-size: 10vw;margin: 20px;}iframe {

  width: 80%;
}.minimap{width: 80%;}} @media screen and (min-width: 900px){
  .score{font-family: 'Impact';
font-style: normal;
font-size: 5vw;
margin-right: 20%;color: #fff;}iframe {

  width: 100%;
}.minimap{width: 100%;}}
</style>

  </head>
   <body>

    <html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Leaderboard UI Design</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
  <section class="main-content">
    <div class="containertest">

    <div class="container">
                <?php include("nav.php"); ?>
    <h3 align="center">Les meilleurs joueurs de l'application*</h3>
    <br> <h3 align="center">Rentrez aussi dans le tableau pour recevoir des cadeaux**</h3>
    <h4 align="center">*(Les joueurs sont classé par score et non par objets trouvés)<br>**(Durant certaines périodes des conceours ont lieu pour avoir des récompense)</h4>

      <br>
      <br>




     

     
    <?php
$bdd = new PDO("mysql:host=localhost;dbname=maps_valence;charset=utf8", "root", "");
$req = $bdd->query('SELECT * FROM membres ORDER BY score DESC');
$i=0;
while ($result = $req->fetch()) {
$i=$i+1;
 if ($i==1) {
      ?><div class="row">
        <div class="col-sm-4">
          <div class="leaderboard-card">
            <div class="leaderboard-card__top">
              <h3 class="text-center"><?php echo ($result['pseudo']);?></h3>
            </div>
            <div class="leaderboard-card__body">
              <div class="text-center">
                <img src="img/user2.jpg" class="pp" alt="User Img">
                <h5 class="mb-0"><?php echo ($result['score']);?></h5>
                <p class="text-muted mb-0"><?php echo ($result['nombre']);?> objets trouvés</p>
                <hr>
                <div class="d-flex justify-content-between align-items-center">
                  <span> Compte crée le: <?php echo ($result['date']);?></span>
                  <a href="profil.php?id=<?php echo($result['id'])?>" class="btn btn-success btn-sm"> voir le profil</a>
                </div>
              </div>
            </div>
          </div>
        </div><?php
    }if ($i==2) {
      ?>         <div class="col-sm-4">
          <div class="leaderboard-card leaderboard-card--first">
            <div class="leaderboard-card__top">
              <h3 class="text-center"><?php echo ($result['pseudo']);?></h3>
            </div>
            <div class="leaderboard-card__body">
              <div class="text-center">
                <img src="img/user1.jpg" class="pp" width="10px">
                <h5 class="mb-0"><?php echo ($result['score']);?></h5>
                <p class="text-muted mb-0"><?php echo ($result['nombre']);?> objets trouvés</p>
                <hr>
                <div class="d-flex justify-content-between align-items-center">
                  <span> Compte crée le: <?php echo ($result['date']);?></span>
                  <a href="profil.php?id=<?php echo($result['id'])?>" class="btn btn-success btn-sm"> voir le profil</a>
                </div>
              </div>
            </div>
          </div>
        </div><?php
    }if ($i==3){?>         <div class="col-sm-4">
          <div class="leaderboard-card">
            <div class="leaderboard-card__top">
              <h3 class="text-center"><?php echo ($result['pseudo']);?></h3>
            </div>
            <div class="leaderboard-card__body">
              <div class="text-center">
                <img src="img/user3.jpg" class="pp" alt="User Img">
                <h5 class="mb-0"><?php echo ($result['score']);?></h5>
                <p class="text-muted mb-0"><?php echo ($result['nombre']);?> objets trouvés</p>
                <hr>
                <div class="d-flex justify-content-between align-items-center">
                  <span>Compte crée le: <?php echo ($result['date']);?></span>
                  <a href="profil.php?id=<?php echo($result['id'])?>" class="btn btn-success btn-sm"> voir le profil</a>
                </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div> <?php 
    }if ($i==4){?>
 <table class="table" align="center">
        <thead>
          <tr>
             <h2>Tout Les Joueurs</h2>
            <th>Pseudo</th>
            <th>Score</th>
            <th>Nombre d'objets trouvés</th>
            <th>Email</th>
            <th>Compte</th>
          </tr>
        </thead>
        <tbody><?php }if ($i>3){?>


          <tr>
            <td>
              <div class="d-flex align-items-center" align="center">
                
                <div class="user-info__basic">
                  <h5 class="mb-0"><?php echo ($result['pseudo']);?></h5>
                </div>
              </div></div>
            </td>
            <td>
              <div class="d-flex align-items-baseline">
                <h4 class="mr-1"><?php echo ($result['score']);?></h4>
              </div>
            </td>
            <td><?php echo ($result['nombre']);?></td>
            <td><?php echo ($result['date']);?></td>
            <td>
              <a href="profil.php?id=<?php echo($result['id'])?>" class="btn btn-success btn-sm"> voir le profil</a>
          </tr>


  
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
<?php }}?>

</body>
  </body>
</html>