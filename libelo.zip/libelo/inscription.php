	<?php
$bdd = new PDO('mysql:host=127.0.0.1;dbname=maps_valence', 'root', '');
 
if(isset($_POST['forminscription'])) {
   $pseudo = htmlspecialchars($_POST['pseudo']);
   $mail = htmlspecialchars($_POST['mail']);
   $mdp= htmlspecialchars($_POST['mdp']);
   $mdp2= htmlspecialchars($_POST['mdp2']);
   $date=date('d-m-Y');

   if(!empty($_POST['pseudo']) AND !empty($_POST['mail']) AND !empty($_POST['mdp']) AND !empty($_POST['mdp2'])) {
      $pseudolength = strlen($pseudo);
      if($pseudolength <= 255) {
            if(filter_var($mail, FILTER_VALIDATE_EMAIL)) {
               $reqmail = $bdd->prepare("SELECT * FROM membres WHERE mail = ?");
               $reqmail->execute(array($mail));
               $mailexist = $reqmail->rowCount();
               if($mailexist == 0) {
                  if($mdp == $mdp2) {
                     $insertmbr = $bdd->prepare("INSERT INTO `membres`( `pseudo`, `mail`, `motdepasse`, `grade`, `score`,`nombre`, `date`) VALUES (?, ?, ?,0,0,0,?)");
                     $insertmbr->execute(array($pseudo, $mail, $mdp, $date));
                     $erreur = header("Location:connexion.php");
                  } else {
                     $erreur = "Vos mots de passes ne correspondent pas !";
                  }
               } else {
                  $erreur = "Adresse mail déjà utilisée !";
               }
            } else {
               $erreur = "Votre adresse mail n'est pas valide !";
            }
         }
      } else {
         $erreur = "Votre pseudo ne doit pas dépasser 255 caractères !";
      }
   } else {
      $erreur = "Tous les champs doivent être complétés !";
   }

?>
   <html>
   <head>
      <title>TUTO PHP</title>
      <meta charset="utf-8">
          <meta charset="utf-8">
      <link href="https://fonts.googleapis.com/css?family=Archivo:500|Open+Sans:300,700" rel="stylesheet">
                  <style type="text/css">  

                     @media screen and (max-width: 1250px){
                     input{border-width: 0px;border-bottom-width: 1px;border-color: #000;margin: 2rem; padding-left: 2rem;width: 70%;height: 30px;font-size: 30px; background: none;display: flex;}
            input[name="forminscription"] {background: linear-gradient(to right, #680027, #E86600);;border: none;border-radius: 25px;padding: 1px;color:#fff;margin: 15px;width: 40%;display: inline-block;align-items: center;}
            body{
            display: grid;justify-content: center;align-items: center;}
            img{width: 50%;margin-bottom: 10px;}
            h2{background: linear-gradient(to right, #680027, #E86600);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent; font-family: 'Archivo', sans-serif;font-size: 4.5rem;}
            h3{background: linear-gradient(to right, #680027, #E86600);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;; font-family: 'Archivo', sans-serif;font-size: 2.5rem;}
            label{; font-family: 'Archivo', sans-serif;font-size: 150%;}
            .all{margin-top: 0px;}
}
                     @media screen and (min-width: 1250px){
                     input{border-width: 0px;border-bottom-width: 3px;border-color: #ffffff;margin: 1.80rem; padding-left: 2rem;width: 500px;height: 50px;font-size: 50px; background: none;display: flex;color: #ffffff}
            input[name="forminscription"] {background-color: #cc4314;padding-bottom: 25px;border: none;border-radius: 15px;margin: 15px;position: relative:font-size: 40px;}
            body{
            background: url(inscription.png); background-size: cover}
            img{position: absolute;left: 40vw;top: 10%;width: 100%;}
            h2{color: #fff; font-family: 'Archivo', sans-serif;font-size: 65px;background: }
            h3{color: #fff; font-family: 'Archivo', sans-serif;font-size: 30px;background: }
            label{color: #000; font-family: 'Archivo', sans-serif;font-size: 15px;}
            .all{margin-top: 0px;}
}
            



</style>

   </head>
   <body>
      <div align="center">
        
         <h2>Bienvenue</h2>
         <h3>Rejoignez notre communauté et commencez à juger les libelos de Valence</h3>
         <form method="POST" action="">
                     <label for="pseudo">Pseudo :</label>


                     <input type="text" placeholder="Votre pseudo" id="pseudo" name="pseudo" value="<?php if(isset($pseudo)) { echo $pseudo; } ?>" />

                     <label for="mail">Mail :</label>


                     <input type="email" placeholder="Votre mail" id="mail" name="mail" value="<?php if(isset($mail)) { echo $mail; } ?>" />
                     <label for="mdp">Mot de passe :</label>
                     <input type="password" placeholder="Votre mot de passe" id="mdp" name="mdp" />
                     <label for="mdp2">Confirmation mot de passe :</label>
                     <input type="password" placeholder="Confirmez-le" id="mdp2" name="mdp2" />

                     <br />
                     <input type="submit" name="forminscription" value="Je m'inscris" />

         </form>
         <?php
         if(isset($erreur)) {
            echo '<font color="red">'.$erreur."</font>";
         }
         ?>
      </div>
   </body>
</html>