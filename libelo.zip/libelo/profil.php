<?php
session_start();

// Si non connecté
if (!isset($_SESSION['id'])) {
    header("Location: connexion.php");
    exit();
}

// Connexion BDD
$bdd = new PDO('mysql:host=127.0.0.1;dbname=libelo', 'root', '');

// Récupération infos utilisateur
$requser = $bdd->prepare("SELECT * FROM membres WHERE id = ?");
$requser->execute([$_GET['id']]);
$userinfo = $requser->fetch();
if ($userinfo== false) {
   header("Location: index.php");
};
// Détermination du rôle selon le grade
$role = "Simple utilisateur";
if ($userinfo['grade'] == 1) {
    $role = "Membre (ajoute des vélos)";
} elseif ($userinfo['grade'] == 2) {
    $role = "Modérateur";
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
   <meta charset="UTF-8">
   <title>Profil - <?= htmlspecialchars($userinfo['pseudo']) ?></title>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <style>
      body {
         font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
         background: linear-gradient(135deg, #4facfe, #00f2fe);
         min-height: 100vh;
         display: flex;
         justify-content: center;
         align-items: center;
         margin: 0;
      }
      .profile-card {
         background: white;
         padding: 2.5rem;
         border-radius: 12px;
         box-shadow: 0 10px 25px rgba(0,0,0,0.15);
         width: 100%;
         max-width: 450px;
         text-align: center;
         animation: fadeIn 0.8s ease-in-out;
      }
      @keyframes fadeIn {
         from { opacity: 0; transform: translateY(-20px); }
         to { opacity: 1; transform: translateY(0); }
      }
      h2 {
         margin-bottom: 0.5rem;
         color: #333;
      }
      .info {
         margin: 1rem 0;
         font-size: 1rem;
         color: #444;
         text-align: left;
      }
      .info strong {
         display: inline-block;
         width: 150px;
         color: #222;
      }
      .score {
         font-size: 1.2rem;
         font-weight: bold;
         margin-top: 1.5rem;
         color: #007bff;
      }
      .logout {
         margin-top: 2rem;
      }
      .logout a {
         display: inline-block;
         background: linear-gradient(90deg, #4facfe, #00f2fe);
         color: white;
         padding: 0.8rem 1.5rem;
         border-radius: 8px;
         text-decoration: none;
         transition: transform 0.15s, box-shadow 0.15s;
      }
      .logout a:hover {
         transform: translateY(-2px);
         box-shadow: 0 5px 15px rgba(0,0,0,0.2);
      }
   </style>
</head>
<body>
   <div class="profile-card">
      <h2>👤 Profil</h2>

      <div class="info">
         <strong>Pseudo :</strong> <?= htmlspecialchars($userinfo['pseudo']); ?>
      </div>

      <div class="info">
         <strong>Rôle :</strong> <?= $role; ?>
      </div>

      <?php if ($userinfo['grade'] == 2): ?>
      <div class="info">
         <strong>Email :</strong> <?= htmlspecialchars($userinfo['mail']); ?>
      </div>
      <?php endif; ?>

      <div class="info">
         <strong>Date de création :</strong> <?= date("d/m/Y", strtotime($userinfo['date'])); ?>
      </div>

      <div class="score">
         🚲 Score : <?= $userinfo['score'] ?> vélos reportés
      </div>

      <div class="logout">
         <a href="deconnexion.php">Se déconnecter</a>
      </div>
   </div>
</body>
</html>
