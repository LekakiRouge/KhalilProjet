<?php
session_start();
$bdd = new PDO('mysql:host=127.0.0.1;charset=utf8;dbname=libelo', 'root', '');
if(isset($_GET['id']) AND !empty($_GET['id'])) {

$get_id = htmlspecialchars ($_GET['id']);
$velo = $bdd->prepare('SELECT  * FROM liste WHERE id = ? ');
$velo->execute(array($get_id));
 if ($velo->rowCount () == 1) {
     $velo = $velo->fetch();
     $qrcode = $velo['QR code'];
     $type = $velo["type"];
     $commentaire = $velo["commentaire"];
     $freinAvant = $velo["freinAvant"];
     $freinAvantNote = $velo["freinAvantNote"];
     $freinArriere = $velo["freinArriere"];
     $freinArriereNote = $velo["freinArriereNote"];
     $cadre = $velo["pedalesChaineVitesseElectrique"];
     $cadreNote = $velo["pedaleNote"];
     $selle = $velo["selle"];
     $selleNote = $velo["selle note"];
     $moyenne = $velo["moyenne"];
 }else {
    die('Cet article n \' existe pas !');
}
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro' rel='stylesheet' type='text/css'>
	<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">
	<title>Libelo </title>
	<style type="text/css">
		@media screen and (min-width: 601px) {
		.banner{background-color: #dfdfdf; width: 100%;height: 10%;}
		img{width: 30%;}
		body  {width: 100%; height: 100%; margin: 0px}
		
		.information > div {display: flex;flex-direction: line; justify-content: space-between ; }
		.information > div > h1 {color: #969696;font-family: 'Source Sans Pro', sans-serif; font-size: 3vw;margin:10px}
		 .information > div >div > h1 {color: #969696;font-family: 'Source Sans Pro', sans-serif; font-size: 3vw;margin-bottom:0px;margin-top:10px } 
		h3 {color: #969696;font-family: 'Open Sans', sans-serif; sans-serif; font-size: 2vw;margin:10px}
		 h2 {color: #969696;font-family: 'Open Sans', sans-serif;, sans-serif; font-size: 1vw;margin-top:-10px} 
		 .grade , .comment{display: flex;flex-direction: column;}
	}
	
	@media screen and (max-width: 600px) {
		.banner{background-color: #dfdfdf; width: 100%;height: 10%;}
		img{width: 90%;}
		body  {width: 100%; height: 100%; margin: 0px}
		
		.information > div{display: flex;flex-direction: line; justify-content: space-between ; ;}
		.information > div > h1 {color: #969696;font-family: 'Source Sans Pro', sans-serif; font-size: 5vw;margin:10px}
		 .information > div >div > h1 {color: #969696;font-family: 'Source Sans Pro', sans-serif; font-size: 5vw;margin-bottom:0px;margin-top:10px } 
		 h3 {color: #969696;font-family: 'Open Sans', sans-serif; sans-serif; font-size: 4vw;margin-top:10px}
		 h2 {color: #969696;font-family: 'Open Sans', sans-serif; sans-serif; font-size: 2vw;margin-top:3px} 
		 .grade , .comment{display: flex;flex-direction: column;}
	}
	 
 
<?php
 if ($type == "Éléctrique" OR $type == "éléctrique") {
	$img_link="elibelo.png";
}else{$img_link="libelo.jpeg";}
 ?>

	</style>
</head>
<body>
<div class="banner" align="center"><img src="<?=$img_link ?>" align="center" > </div>
<div class="information" align="center">
	<div class="biketype"><h1 align="left">Type de vélo</h1><h3 align="right"><?=$type ?></h3></div>

	<div class="qrcode"><h1 align="left">QR code</h1><h3 align="right"><?=$qrcode ?></h3></div>

	<div class="frontbake">
		<div class="name">
			<h1 align="left">Frein Avant</h1>
			<h2 align="left">Note Frein Avant</h2>
		</div>
		 <div class="result">
		 	<h3 align="right"><?=$freinAvant ?></h3> 
		 	<h2 align="right"><?=$freinAvantNote ?>/10</h2>
		 </div>
	</div>
	<div class="backbake">
		<div class="name">
			<h1 align="left">Frein arrière</h1>
			<h2 align="left">Note Frein arrière</h2>
		</div>
		 <div class="result">
		 	<h3 align="right"><?=$freinArriere ?></h3> 
		 	<h2 align="right"><?=$freinAvantNote ?>/10</h2>
		 </div>
	</div>
	<div class="pedal">
		<div class="name">
			<h1 align="left">Pédales/Chaîne/Vitesse/Éléctrique
</h1>
			<h2 align="left">Note pédales/chaîne/vitesse/Éléctrique
</h2>
		</div>
		 <div class="result">
		 	<h3 align="right"><?=$cadre ?>
</h3> 
		 	<h2 align="right"><?=$cadreNote ?>/10</h2>
		 </div>
	</div>
	<div class="saddle">
		<div class="name">
			<h1 align="left">Selle</h1>
			<h2 align="left">Note selle </h2>
		</div>
		 <div class="result">
		 	<h3 align="right"><?=$selle ?></h3> 
		 	<h2 align="right"><?=$selleNote ?>/10</h2>
		 </div>
	</div>
	<div class="comment" align="center"><h1 align="center">Commentaires supplémentaires:</h1><h3 align="center"><?=$commentaire ?>
</h3> </div>
	<div class="grade" align="center"><div> <h1 align="center">Moyenne:<?=$moyenne ?></h1> </div>

</div>
</div>
</body> 
</html>