<?php
session_start();
$rand=(rand(1,2));
$bdd = new PDO('mysql:host=127.0.0.1;dbname=maps_valence', 'root', '');
 
if(isset($_GET['id']) AND $_GET['id'] > 0) {
   $getid = intval($_GET['id']);
   $requser = $bdd->prepare('SELECT * FROM membres WHERE id = ?');
   $requser->execute(array($getid));
   $userinfo = $requser->fetch();
   if($userinfo==false){
      echo"test";header("Location:connexion.php");
   }}
?>
<html>
   <head>
      <title>TUTO PHP</title>
      <meta charset="utf-8">
    <meta charset="utf-8">
      <link href="https://fonts.googleapis.com/css?family=Archivo:500|Open+Sans:300,700" rel="stylesheet">
                  <style type="text/css">  

                  
                     @media screen and (min-width: 1250px){
            h2{color: rgba(0, 0, 0, 0.5);; font-family: 'Archivo', sans-serif;font-size: 65px;}
            h3{color: rgba(0, 0, 0, 0.5); font-family: 'Archivo', sans-serif;font-size: 40px;}
            <?php 
            if ($userinfo['grade']==1){$status="This account is a publisher account" ?>
             .publisher{content:url(publisher.png);width: 150px;height: 100px}
          <?php  }
            if ($userinfo['grade']==2){$status="This account is a developer/moderator account" ?>
             .publisher{content:url(dev.png);width: 170px;height: 150px}
          <?php  }else{$status="This account is a player account" ?>
             .publisher{content:url(player.png);width: 170px;height: 150px}} <?php } ?>




            <?php  if($rand==2){?>

               body{background: rgb(0,104,255);
            background: linear-gradient(65deg, rgba(0,104,255,1) 60%, rgba(0,232,255,1) 100%, rgba(0,104,255,1) 100%);
            }.PP{content:url(femmePP.png);width: 290px;height: 250px}


            <?php }else{?>

               body{background: rgb(255,252,0);
               background: linear-gradient(-150deg, rgba(255,252,0,1) 0%, rgba(255,0,232,1) 100%);}
               .PP{content:url(hommePP.png);width: 290px;height: 250px}
                }; }<?php }?>






           


            



</style>

   </head>
   <body align="center">
      <div align="center"><br><br>
         <h2>Profil de <?php echo $userinfo['pseudo']; ?></h2>
         <img src="PP" class="PP" />
         <img src="STATUS" class="publisher">
         <h3 ><?php echo'<span style="font-size: 10px;"> '.$status?></h3>
         
         
         <h3><?php echo $userinfo['bio']; ?></h3>
         <h3>Mail = <?php echo $userinfo['mail']; ?></h3>
         <h3>Score = <?php echo $userinfo['score']; ?></h3>
         <h3>Récompense trouvé = <?php echo $userinfo['nombre']; ?></h3>
         <h3>actif depuis le = <?php echo $userinfo['date']; ?></h3>
         <br />
         <?php
         if(isset($_SESSION['id']) AND $userinfo['id'] == $_SESSION['id']) {
         ?>
         <br />
         <a href="editionprofil.php">Editer mon profil</a>
         <a href="deconnexion.php">Se déconnecter</a>
         <?php
         }
         ?>
      </div>
   </body>
</html>
