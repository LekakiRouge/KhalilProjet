<?php
session_start();
$bdd = new PDO('mysql:host=127.0.0.1;charset=utf8;dbname=libelo', 'root', '');
$default=true;
if (isset($_POST['subsearch'])) {
  if (isset($_POST['search']) && strlen($_POST['search']) > 2) {
    $request = $_POST['search']; 
        $velos = $bdd->prepare('SELECT * FROM liste WHERE `qr code` LIKE ? ');
        $velos->execute(array('%'.$request.'%'));
        $default=false;

      




 	}else{$velos = $bdd->query('SELECT * FROM liste ORDER BY moyenne DESC');}
 } 
 else{

$velos = $bdd->query('SELECT * FROM liste ORDER BY moyenne DESC');
}
?>
<!DOCTYPE html>
<html>
<head>
	<script src="https://unpkg.com/html5-qrcode"></script>
	<style>

		@media screen and (min-width: 601px) {
		.bouton{display: flex; flex-direction: line;width: 100%;height: 20%;justify-content: space-between;
		 border-bottom-width:2px; 
		 border-bottom-color:#000; 
		 border-bottom-style: solid;
		}

		.gauche{width: 30%;background-color: #dfdfdf;margin-left: -8px;margin-top: -8px;z-index: -1}
		.gauche> img{ background-color: #dfdfdf;margin-bottom: -5%; width: 75%;z-index: -5;}
		.gauche> h1{position: relative;
		 background: linear-gradient(to right, #680027, #E86600);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;z-index: 100;}
		.all_note{display: flex; flex-direction: line;}
		.droite{margin-right: 15%}
		h1{color: #969696;font-family: 'Source Sans Pro', sans-serif; font-size: 2vw;margin:10px;}
		a{text-decoration: none;}
		.moyenne{color:#000000}
		.search{width:60%;padding:2%;font-size:1.2rem;border-radius:70px;border:1px solid #cc4314;}
			.subsearch{padding:1rem 2rem;font-size:1.2rem;border-radius:50px;background:#cc4314;color:#fff;border:none;cursor:pointer;}
			#open-qr{padding:1rem 2rem;font-size:1.2rem;border-radius:50px;background:#007bff;color:#fff;border:none;cursor:pointer;margin-left:10px;}
		

}


@media screen and (max-width: 600px) {
		.bouton{display: flex; flex-direction: line;width: 100%;height: 50%;justify-content: space-between;
		 border-bottom-width:2px; 
		 border-bottom-color:#000; 
		 border-bottom-style: solid;
		}

		.gauche{width: 50%;background-color: #dfdfdf;margin-left: -8px;margin-top: -2px;z-index: -1}
		.gauche> img{ background-color: #dfdfdf;margin-bottom: -5%; width: 90%;z-index: -5;}
		.gauche> h1{position: relative; background: linear-gradient(to right, #680027, #E86600);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;}
		.all_note{display: flex; flex-direction: line;}
		.droite{margin-right: 1%}
		h1{color: #969696;font-family: 'Source Sans Pro', sans-serif; font-size: 3.5vw;margin:3px;}
		a{text-decoration: none;}
		.moyenne{color:#000000}
.search{width:70%;padding:2%;font-size:0.9rem;border-radius:50px;border:1px solid #cc4314;}
			.subsearch{padding:0.6rem 1rem;font-size:0.9rem;border-radius:50px;background:#cc4314;color:#fff;border:none;}
			 #open-qr{padding:0.6rem 1rem;font-size:0.9rem;border-radius:50px;background:#007bff;color:#fff;border:none;margin-top:5px;}
		}
		#qr-reader {width:300px;margin:20px auto;display:none; }
      button{transition: 0.5s;background: none;border-width: 0px}
      button:hover{transition: 0.3s; margin: 1.2rem}

	 </style>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Tous les vélos</title>
</head>
<body>

<form method="post" action="" align="center">
	<br><br>
	<input type="search" class="search" id="search" name="search" placeholder="Tapez minimum 3 caractères du QR code">
	<input type="submit" class="subsearch" id="subsearch" name="subsearch" value="Rechercher">
<button type="button" id="open-qr"><img width=50px src="https://cdn-icons-png.flaticon.com/512/1363/1363991.png"></button>
</form>

<!-- Fenêtre modale pour scanner -->
<div id="qr-modal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%;z-index: 999; background:rgba(0,0,0,0.8); align-items:center; justify-content:center;">
   <div style="background:white; padding:1rem; border-radius:8px; max-width:400px; width:90%;">
      <h3>Scanner un QR Code</h3>
      <div id="reader" style="width:100%;"></div>
      <button id="close-qr" style="margin-top:1rem;">Fermer</button>
   </div>
</div>




<br><br><br> <?php if($default){ echo("<div   align='center'class='gauche'>  <h1>Les meilleurs vélos</h1> </div> <?php "); }elseif (!$default) {
	 echo("<div   align='center'class='gauche'>  <h1>Résultats</h1> </div> <?php ");
} ?> <br>


	<?php while ($v = $velos->fetch() ) {?>
		
	<a href="./velo.php?id=<?=$v['id'] ?>">

	<div class="bouton">
	<div class="gauche" align="center"> 
		<img src="<?php
 	if ($v['type'] == "Éléctrique" OR $v['type'] == "éléctrique") { echo"elibelo.png";
	}else{echo"libelo.jpeg";}

 ?>" align="center">
		<h1 align="center"><?= $v['QR code'];?></h1>
	</div>

	<div class="droite" align="right" > 
		<div class="all_note" > 
		<div class="note_gauche" align="left">
			<h1>Frein avant: <?= $v['freinAvantNote'];?>/10</h1>
			 <h1>Frein arrière: <?= $v['freinArriereNote'];?>/10</h1> 
		</div>
		 <div class="note_droite"  align="right">
		 	<h1>cadre: <?= $v['pedaleNote'];?>/10</h1>
		 	<h1>selle: <?= $v['selle note'];?>/10</h1> 
		 </div>
		</div>
		 <h1 align="center" class="moyenne">Moyenne <?= $v['moyenne'];?>/10</h1> 
	</div>
</div>

</a>

<?php }?>
<script>
   const modal = document.getElementById("qr-modal");
   const openBtn = document.getElementById("open-qr");
   const closeBtn = document.getElementById("close-qr");
   const qrInput = document.getElementById("qr-input");
   let html5QrCode;

   openBtn.addEventListener("click", () => {
      modal.style.display = "flex";
      if (!html5QrCode) {
         html5QrCode = new Html5Qrcode("reader");
      }
      html5QrCode.start(
         { facingMode: "environment" },
         { fps: 10, qrbox: 250 },
         qrCodeMessage => {
            qrInput.value = qrCodeMessage; // on met le QR dans l’input
            html5QrCode.stop().then(() => {
               modal.style.display = "none"; // fermer la modale
            });
         },
         errorMessage => {
            // erreurs ignorées (scanner continue)
         }
      ).catch(err => {
         alert("Impossible d'accéder à la caméra : " + err);
      });
   });

   closeBtn.addEventListener("click", () => {
      if (html5QrCode) {
         html5QrCode.stop();
      }
      modal.style.display = "none";
   });
</script></body>

</html>