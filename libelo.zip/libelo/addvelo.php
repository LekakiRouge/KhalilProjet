<?php
session_start();

// Connexion à la base
$bdd = new PDO('mysql:host=127.0.0.1;dbname=libelo', 'root', '');

if (isset($_POST['formvelo'])) {
   // Sécurisation des entrées
   $type = htmlspecialchars($_POST['type']);
   $qr   = htmlspecialchars($_POST['qr']);
   $commentaire = htmlspecialchars($_POST['commentaire']);

   $freinAvant = htmlspecialchars($_POST['freinAvant']);
   $freinAvantNote = htmlspecialchars($_POST['freinAvantNote']);

   $freinArriere = htmlspecialchars($_POST['freinArriere']);
   $freinArriereNote = htmlspecialchars($_POST['freinArriereNote']);

   $pedales = htmlspecialchars($_POST['pedalesChaineVitesseElectrique']);
   $pedaleNote = htmlspecialchars($_POST['pedaleNote']);

   $selle = htmlspecialchars($_POST['selle']);
   $selleNote = htmlspecialchars($_POST['selleNote']);

   $moyenne = htmlspecialchars($_POST['moyenne']);

   // Vérif des champs obligatoires
   if (!empty($type) && !empty($qr)) {
      $insertvelo = $bdd->prepare("INSERT INTO `liste`(`type`, `QR code`, `commentaire`, `freinAvant`, `freinAvantNote`, `freinArriere`, `freinArriereNote`, `pedalesChaineVitesseElectrique`, `pedaleNote`, `selle`, `selle note`, `moyenne`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

      $success = $insertvelo->execute(array(
          $type, $qr, $commentaire,
         $freinAvant, $freinAvantNote,
         $freinArriere, $freinArriereNote,
         $pedales, $pedaleNote,
         $selle, $selleNote, $moyenne
      ));

      if ($success) {
         $msg = "✅ Vélo ajouté avec succès !";
      } else {
         $erreur = "❌ Erreur lors de l'ajout du vélo.";
      }
   } else {
      $erreur = "Tous les champs obligatoires (*) doivent être remplis.";
   }
}
?>
<html>
   <head>
   <meta charset="utf-8">
   <title>Ajouter un vélo</title>
   <style>
      body {
         font-family: Arial, sans-serif;
         background: #f4f4f9;
         margin: 0;
         padding: 0;
         display: flex;
         flex-direction: column;
         align-items: center;
      }
      header {
         width: 100%;
         height: 35%;
         background: #dedede;
         display: flex;
         align-items: center;
         justify-content: center;
      }
      header img {
         max-height: 100%;
         object-fit: cover;
      }
      h2 {
         margin: 1rem 0;
         color: #333;
      }
      form {
         background: white;
         padding: 2rem;
         border-radius: 8px;
         box-shadow: 0 4px 10px rgba(0,0,0,.1);
         display: grid;
         gap: 0.8rem;
         width: 90%;
         max-width: 500px;
      }
      label {
         font-weight: bold;
         color: #444;
         margin-top: 0.4rem;
      }
      input, textarea {
         padding: 0.6rem;
         border: 1px solid #ccc;
         border-radius: 5px;
         width: 100%;
         font-size: 1rem;
      }
      .radio-group {
         display: flex;
         gap: 1rem;
         align-items: center;
      }
      input[type=submit] {
         transition: 1.5s;
         background: linear-gradient(to right, #680027, #E86600);
         color: #fff;
         border: none;
         cursor: pointer;
         font-size: 1.3rem;
         margin-top: 1rem;
      }
      input[type=submit]:hover {
         transition: 0.3s;
         color: #000;
         margin-top: 1.15rem;
      }
      input[type=submit]:unhover {
         transition: 1s;
         color: #fff;
         margin-top: 1rem;
      }
      .msg {
         margin-top: 1rem;
         font-weight: bold;
         text-align: center;
      }
      button{transition: 0.5s;background: none;border-width: 0px}
      button:hover{transition: 0.3s; margin: 1.2rem}
   </style>
</head>
<body>
   <header>
      <img id="banner" src="libelo.jpeg" alt="Bannière vélo" class="banner">
   </header>

   <h2>Ajouter un vélo</h2>

   <form method="POST" action="">

      <label>Type</label>
      <div class="radio-group">
         <label><input type="radio" name="type" value="mecanique" checked> Mécanique</label>
         <label><input type="radio" name="type" value="electrique"> Électrique</label>
      </div>

      <label>QR code</label>
<div style="display:flex; gap:0.5rem; align-items:center;">
   <input type="text" name="qr" id="qr-input" required />
   <button type="button" id="open-qr"><img width=50px src="https://cdn-icons-png.flaticon.com/512/1363/1363991.png"></button>
</div>


      <label>Commentaire</label>
      <textarea name="commentaire"></textarea>

      <label>Frein avant</label>
      <input type="text" name="freinAvant" />
      <input type="number" name="freinAvantNote" placeholder="Note frein avant" min="0" max="10" />

      <label>Frein arrière</label>
      <input type="text" name="freinArriere" />
      <input type="number" name="freinArriereNote" placeholder="Note frein arrière" min="0" max="10" />

      <label>Pédales / chaîne / vitesses / électrique</label>
      <input type="text" name="pedalesChaineVitesseElectrique" />
      <input type="number" name="pedaleNote" placeholder="Note pédales" min="0" max="10" />

      <label>Selle</label>
      <input type="text" name="selle" />
      <input type="number" name="selleNote" placeholder="Note selle" min="0" max="10" />

      <label>Moyenne</label>
      <input type="number" step="0.01" name="moyenne" readonly />

      <input type="submit" name="formvelo" value="Enregistrer le vélo" />
   </form>
<!-- Fenêtre modale pour scanner -->
<div id="qr-modal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.8); align-items:center; justify-content:center;">
   <div style="background:white; padding:1rem; border-radius:8px; max-width:400px; width:90%;">
      <h3>Scanner un QR Code</h3>
      <div id="reader" style="width:100%;"></div>
      <button id="close-qr" style="margin-top:1rem;">Fermer</button>
   </div>
</div>

   <?php
   if(isset($erreur)) {
      echo '<div class="msg" style="color:red">'.$erreur.'</div>';
   }
   if(isset($msg)) {
      echo '<div class="msg" style="color:green">'.$msg.'</div>';
   }
   ?>

   <script>
      // Calcul de la moyenne
      const notes = document.querySelectorAll('input[type=number][name$="Note"]');
      const moyenneInput = document.querySelector('input[name="moyenne"]');
      notes.forEach(input => {
         input.addEventListener('input', () => {
            let vals = [];
            notes.forEach(n => { if (n.value) vals.push(parseFloat(n.value)); });
            if (vals.length > 0) {
               let moy = vals.reduce((a,b)=>a+b,0)/vals.length;
               moyenneInput.value = moy.toFixed(2);
            } else {
               moyenneInput.value = "";
            }
         });
      });

      // Bannière dynamique
      const radios = document.querySelectorAll('input[name="type"]');
      const banner = document.getElementById('banner');
      radios.forEach(r => {
         r.addEventListener('change', () => {
            if (r.value === "electrique") {
               banner.src = "elibelo.png";
            } else {
               banner.src = "libelo.jpeg";
            }
         });
      });
   </script>
   <!-- Librairie QR -->
<script src="https://unpkg.com/html5-qrcode"></script>
<script>
   const modal = document.getElementById("qr-modal");
   const openBtn = document.getElementById("open-qr");
   const closeBtn = document.getElementById("close-qr");
   const qrInput = document.getElementById("qr-input");
   let html5QrCode;

   openBtn.addEventListener("click", () => {
      modal.style.display = "flex";
      if (!html5QrCode) {
         html5QrCode = new Html5Qrcode("reader");
      }
      html5QrCode.start(
         { facingMode: "environment" },
         { fps: 10, qrbox: 250 },
         qrCodeMessage => {
            qrInput.value = qrCodeMessage; // on met le QR dans l’input
            html5QrCode.stop().then(() => {
               modal.style.display = "none"; // fermer la modale
            });
         },
         errorMessage => {
            // erreurs ignorées (scanner continue)
         }
      ).catch(err => {
         alert("Impossible d'accéder à la caméra : " + err);
      });
   });

   closeBtn.addEventListener("click", () => {
      if (html5QrCode) {
         html5QrCode.stop();
      }
      modal.style.display = "none";
   });
</script>

</body>
</html>