<?php

  
    include('upload-code.php'); // Include upload code Script page.
    
$bdd = new PDO("mysql:host=localhost;dbname=maps_valence;charset=utf8", "root", "");
if (isset($_GET['id']) AND !empty($_GET['id'])) {
  $get_id=htmlspecialchars($_GET['id']);
  $reqs = $bdd->prepare('SELECT * FROM reward WHERE id = ?');
  $reqs->execute(array($get_id));



if ($reqs->rowcount() == 1) {
  $reqs = $reqs->fetch();
}else{
  header('Location: index.php');}
}else{
  header('Location: index.php');
}

?>



<html>
  <head>

    <title>Simple Map</title>
    <meta charset="utf-8">
<style type="text/css">/*   color variables */



button {
  font-family: inherit;
  font-size: 1rem;
  border: none;
  cursor: pointer;
}

.btn-primary {
  background-color: #0e48fe;
  border-radius: 0.2rem;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 0.5rem;
  color: #eef1f6;
  padding: 0.5rem;
}
.btn-primary svg {
  width: 1rem;
  fill: #eef1f6;
}

.btn-secondary {
  background-color: transparent;
  font-weight: bold;
  color: #0e48fe;
}

.notification {
  position: absolute;
  left: 50%;
  transform: translatex(-50%);
  background-color: #ffebeb;
  border-radius: 0.2rem;
  overflow: visible;
  display: none;
  justify-content: center;
  align-items: center;
  gap: 1rem;
}
.notification__warning {
  width: 1.5rem;
  margin-left: 1rem;
  fill: #e00000;
}
.notification__close {
  background-color: #ffc2c2;
  padding: 1rem;
  display: flex;
  cursor: pointer;
}
.notification__close svg {
  width: 1rem;
  fill: #e00000;
}
.notification-show {
  animation: warning 400ms ease-in-out forwards;
  display: flex;
}

@keyframes warning {
  0% {
    opacity: 0;
    top: 2rem;
  }
  5% {
    opacity: 0;
  }
  100% {
    opacity: 1;
    top: 4rem;
  }
}


.btns-primary {
  background-color: #0e48fe;
  border-radius: 0.2rem;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 0.5rem;
  color: #eef1f6;
  padding: 0.5rem;
}
.btns-primary svg {
  width: 1rem;
  fill: #eef1f6;
}

.btns-secondary {
  background-color: transparent;
  font-weight: bold;
  color: #0e48fe;
}

.notifications {
  position: absolute;
  left: 50%;
  transform: translatex(-50%);
  background-color: #C8FFCC;
  border-radius: 0.2rem;
  overflow: visible;
  display: none;
  justify-content: center;
  align-items: center;
  gap: 1rem;
}
.notifications__warning {
  width: 1.5rem;
  margin-left: 1rem;
  fill: #76FF80;
}
.notifications__close {
  background-color: #76FF80 ;
  padding: 1rem;
  display: flex;
  cursor: pointer;
}
.notifications__close svg {
  width: 1rem;
  fill: #e00000;
}
.notifications-show {
  animation: warning 400ms ease-in-out forwards;
  display: flex;
}

@keyframes warning {
  0% {
    opacity: 0;
    top: 2rem;
  }
  5% {
    opacity: 0;
  }
  100% {
    opacity: 1;
    top: 4rem;
  }
}</style>
    <style type="text/css">


      iframe{width: 100%;height: 40%;margin: 0px;}
    .adresse{font-family: 'Archivo', sans-serif;
font-style: normal;
font-size:80px;
color: #fff;text-align:center ;}
    .desc{font-family:'Archivo', sans-serif;
font-style: normal;
font-size:40px;
color: #fff; }
.more{display: flex;justify-content: space-between;}
   .pts{font-family: 'Impact', sans-serif;
font-style: normal;
font-size:75px;
color: #fff; }
.text{font-family: 'Archivo', sans-serif;
font-style: normal;
font-size:20px;
color: crimson;background-color: #070025; margin-top: 10px;padding: 20px;margin-bottom:2px;font-family: 'Impact', sans-serif}
.minimap{margin: 0px}




@media screen and (max-width: 1250px){
                     input{border-width: 0px;border-bottom-width: 3px;border-color: #ffffff;margin: 1.80rem; padding-left: 2rem;width: 70%;height: 30px;font-size: 30px; background: none;display: flex;color: #ffffff}
                     input[name="valider"],input[name="btn_upload"] {background: linear-gradient(90deg, rgba(46,0,255,1) 0%, rgba(255,0,254,1) 100%);border: none;border-radius: 15px;margin: 15px;position: relative:font-size: 40px;}
            
            body{background: rgb(0,104,255);
            background: linear-gradient(90deg, rgba(0,104,255,1) 0%, rgba(0,232,255,1) 100%, rgba(255,255,255,1) 100%);margin: 0px;
            }
            img{width: 60%;margin-bottom: 50px;}
            h2{color: #fff; font-family: 'Archivo', sans-serif;font-size: 40px;}
            .desc{color: #fff; font-family: 'Archivo', sans-serif;font-size: 20px;}
            .file_input{
              opacity: 0;

}label{
  background: linear-gradient(-90deg, rgba(46,0,255,1) 0%, rgba(255,0,254,1) 100%);border: none;border-radius: 15px;margin: 15px;color: #fff; font-family: 'Archivo', sans-serif;font-size: 25px;padding: 1.5%;padding: 1%;padding: 1%;
}
.container_main{margin-top: 100px;}
.forms{display: flex;flex-direction: column;}
}
                     @media screen and (min-width: 1250px){
                      .forms{display: flex;justify-content: space-between;}
                     input{border-width: 0px;border-bottom-width: 3px;border-color: #ffffff;margin: 1.80rem; padding-left: 2rem;width: 500px;height: 50px;font-size: 30px; background: none;display: flex;color: #ffffff}
                     input[name="valider"],input[name="btn_upload"] {background: linear-gradient(90deg, rgba(46,0,255,1) 0%, rgba(255,0,254,1) 100%);;border: none;border-radius: 15px;margin: 15px;position: relative:font-size: 40px;}
            
            body{background: rgb(255,252,0);
background: linear-gradient(90deg, rgba(255,252,0,1) 0%, rgba(255,0,232,1) 100%);
margin: 0px;
          }
            img{position: absolute;left: 40vw;top: 10%;width: 100%;}
            h2{color: #fff; font-family: 'Archivo', sans-serif;font-size: 65px;}
            h3{color: #fff; font-family: 'Archivo', sans-serif;font-size: 40px;}
                        .file_input{
              opacity: 0;

}.lab{
  background: linear-gradient(-90deg, rgba(46,0,255,1) 0%, rgba(255,0,254,1) 100%);border: none;border-radius: 15px;margin: 15px;color: #fff; font-family: 'Archivo', sans-serif;font-size: 25px;padding: 1.5%;padding: 1%;padding: 1%;
}
.forms{display: flex;justify-content: space-between;}
}
}
            




  </style>
  </head>
   <body>
    <?php include("nav.php"); ?>
           <div id="notification" class="notification">
    <svg class="notification__warning" viewBox="0 0 512 512" width="100" title="exclamation-circle">
      <path d="M504 256c0 136.997-111.043 248-248 248S8 392.997 8 256C8 119.083 119.043 8 256 8s248 111.083 248 248zm-248 50c-25.405 0-46 20.595-46 46s20.595 46 46 46 46-20.595 46-46-20.595-46-46-46zm-43.673-165.346l7.418 136c.347 6.364 5.609 11.346 11.982 11.346h48.546c6.373 0 11.635-4.982 11.982-11.346l7.418-136c.375-6.874-5.098-12.654-11.982-12.654h-63.383c-6.884 0-12.356 5.78-11.981 12.654z" />
    </svg>
    <p>Mauvais code réessayes ou vas vraiment le chercher (Je te vois :) )</p>
    <button id="close" class="notification__close">
      <svg viewBox="0 0 352 512" width="100" title="times">
        <path d="M242.72 256l100.07-100.07c12.28-12.28 12.28-32.19 0-44.48l-22.24-22.24c-12.28-12.28-32.19-12.28-44.48 0L176 189.28 75.93 89.21c-12.28-12.28-32.19-12.28-44.48 0L9.21 111.45c-12.28 12.28-12.28 32.19 0 44.48L109.28 256 9.21 356.07c-12.28 12.28-12.28 32.19 0 44.48l22.24 22.24c12.28 12.28 32.2 12.28 44.48 0L176 322.72l100.07 100.07c12.28 12.28 32.2 12.28 44.48 0l22.24-22.24c12.28-12.28 12.28-32.19 0-44.48L242.72 256z" />
      </svg>
    </button>
  </div>
  <div id="notifications" class="notifications">
    <svg class="svg-icon" viewBox="0 0 20 20" width="50" title="exclamation-circle">
              <path d="M10.219,1.688c-4.471,0-8.094,3.623-8.094,8.094s3.623,8.094,8.094,8.094s8.094-3.623,8.094-8.094S14.689,1.688,10.219,1.688 M10.219,17.022c-3.994,0-7.242-3.247-7.242-7.241c0-3.994,3.248-7.242,7.242-7.242c3.994,0,7.241,3.248,7.241,7.242C17.46,13.775,14.213,17.022,10.219,17.022 M15.099,7.03c-0.167-0.167-0.438-0.167-0.604,0.002L9.062,12.48l-2.269-2.277c-0.166-0.167-0.437-0.167-0.603,0c-0.166,0.166-0.168,0.437-0.002,0.603l2.573,2.578c0.079,0.08,0.188,0.125,0.3,0.125s0.222-0.045,0.303-0.125l5.736-5.751C15.268,7.466,15.265,7.196,15.099,7.03"></path>
            </svg>
    <p>FÉLICITATION TU AS GAGNÉ DES POINTS</p>
    <button id="closes" class="notifications__close">
      <svg viewBox="0 0 352 512" width="100" title="times">
        <path d="M242.72 256l100.07-100.07c12.28-12.28 12.28-32.19 0-44.48l-22.24-22.24c-12.28-12.28-32.19-12.28-44.48 0L176 189.28 75.93 89.21c-12.28-12.28-32.19-12.28-44.48 0L9.21 111.45c-12.28 12.28-12.28 32.19 0 44.48L109.28 256 9.21 356.07c-12.28 12.28-12.28 32.19 0 44.48l22.24 22.24c12.28 12.28 32.2 12.28 44.48 0L176 322.72l100.07 100.07c12.28 12.28 32.2 12.28 44.48 0l22.24-22.24c12.28-12.28 12.28-32.19 0-44.48L242.72 256z" />
      </svg>
    </button>
  </div>
<?php if(isset($_POST['valider'])) {
  $code = htmlspecialchars($_POST['code']);
  $check = $bdd->prepare('SELECT code FROM reward WHERE code = ?');
   $check->execute(array($code));
   $checknumb = $check->rowCount();
   
   if ($checknumb==1) {
    sleep(2);
     echo "<script> notifications.classList.add('notifications-show'); </script>"; 
   }else{sleep(2);
    echo "<script> notification.classList.add('notification-show'); </script>"; }
  }
?>

 <div class="minimap"><?=$reqs['map']; ?></div>
 <div class="textdefi">
    <div class="outer-container">
    <div class="top-section">
      <p class="adresse"><?=$reqs['adresse']; ?></p>
      <div class="more">
        <p class="desc"><?=$reqs['description']; ?></p>
        <p class="pts">+<?=$reqs['points']; ?><br>Points</p>

      </div>
              <p class="text" align="center">Retrouvez le code (sur une feuille plié) caché dans le secteur, puis entrez le code dans le formulaire de gauche</p>
              <h1 style="font-size: 75px;color: #fff;" align="center">OU BIEN SI</h1>
              <p class="text" align="center">
              le code est introuvable/à un défaut alors uttilisez le formulaire de droite et prenez une phoo de l'emplacement sur la carte vous serez manuellement validés ou refusés</p>
             
              
    </div>
    <div align="center" class="forms">
      
    <form method="POST" action="" >
      <h2 style="font-size: 40px;color: #fff;" align="center">Code sur le papier<br>(délai d'attente: direct)</h2>
                <input name="code" placeholder="Inscrivez le code sur le papier"align="center" />
            <br /><br />
            <input type="submit" name="valider" value="Se connecter !" align="center" />
         </form>

  <div class="container_main" align="center">
    <h1><?php echo($error); ?></h1>
    <div class="image-box">
      <h2 style="font-size: 40px;color: #fff;" align="center">En cas de problème <br>(délai d'attente entre: 1h à 72h)</h2>
      <form method="POST" name="upfrm" action="" enctype="multipart/form-data">
        <div>
          
          <input type="file" name="fileImg" id="file" class="file_input" >
          <label for="file" class="lab">Importez ici votre image</label>
          <input type="text" placeholder="Un commentaire? (faculatif)" name="img_name" class="tb" />
          <input type="submit" value="Upload" name="btn_upload" class="btn" />
        </div>
      </form>
      <div class="msg">

      </div>
    </div>
  </div>
  </div>
  </body>
</html>