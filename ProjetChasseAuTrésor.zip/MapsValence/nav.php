
    <meta charset="utf-8">
    <!-- <title>Sider Menu Bar CSS</title> -->
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Archivo:500|Open+Sans:300,700" rel="stylesheet">
  	<style type="text/css">

@media screen and (max-width: 600px){.navone {visibility: hidden;}.navtwo{visibility: visible;z-index: 900;}}
 @media screen and (min-width: 600px){.navone {visibility: visible; z-index: 900;}.navtwo{visibility: hidden;}}

  		@import url('https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500');
@import url('https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500');
.navtwo{position: sticky;
    top: 100%;
    background-color: #fff;z-index: 900;}

    *{
  padding: 0;
  margin: 0;
  list-style: none;
  text-decoration: none;
}
body {
  font-family: 'Roboto', sans-serif;
}
.sidebar {
  z-index: 50;
  position: fixed;
  left: -250px;
  width: 250px;
  height: 100%;
  background: #232323;
  transition: all .5s ease;
}
.sidebar header {
  font-size: 22px;
  color: white;
  line-height: 70px;
  text-align: center;
  background: #232323;
  user-select: none;
}
.sidebar ul a{
  display: block;

  line-height: 65px;
  font-size: 20px;
  color: white;
  padding-left: 40px;

  transition: .4s;
}
 #scd:hover  a{
  padding-left: 50px;
}
.sidebar ul a i{
  margin-right: 16px;
}
#check{
  display: none;
}
label #btn,label #cancel{
  position: absolute;
  background: #232323;
  border-radius: 3px;
  cursor: pointer;
}
label #btn{
  left: 40px;
  top: 25px;
  font-size: 35px;
  color: white;
  padding: 6px 12px;
  transition: all .5s;
}
label #cancel{
  z-index: 1111;
  left: -195px;
  top: 17px;
  font-size: 30px;
  color: #fff;
  padding: 4px 9px;
  transition: all .5s ease;
}
#check:checked ~ .sidebar{
  left: 0;
}
#check:checked ~ label #btn{
  left: 250px;
  opacity: 0;
  pointer-events: none;
}
#check:checked ~ label #cancel{
  left: 195px;
}
#check:checked ~ section{
  margin-left: 250px;
}
section{
  background-position: center;
  background-size: cover;
  height: 100vh;
  transition: all .5s;
}
:root {
  --main-color: #000;
  --second-color: #000;
}




.navigation-bar {
  border-radius: 3px;
  overflow: hidden;
  box-shadow: 0 15px 25px rgba(0, 0, 0, 0.1);
}
.navigation-bar .list-items {
  list-style: none;
  display: flex;
  position:absolute; bottom: -10px;width: 100%;
}
.navigation-bar .list-items .pointer {
  position: absolute;
  left: 0px;
  height: 100%;
  width: 4.5rem;
  z-index: 0;
  transition: all 0.2s linear;
}
.navigation-bar .list-items .pointer::before,
.navigation-bar .list-items .pointer::after {
  content: "";
  position: absolute;
  left: 0;
  width: 100%;
}
.navigation-bar .list-items .pointer::before {
  top: 0;
  border-bottom: 8px solid var(--main-color);
  border-radius: 0 0 30px 30px;
}
.navigation-bar .list-items .pointer::after {
  bottom: 0;
  border-top: 8px solid var(--main-color);
  border-radius: 30px 30px 0 0;
}

.navigation-bar .list-items .item {
  flex: 1 1 0px;
  position: relative;
  z-index: 2;
}
.navigation-bar .list-items .item .link {
  display: inline-block;
  height: 4rem;
  width: 4.5rem;
  line-height: 4.5;
  text-align: center;
  color: var(--second-color);
}
.navigation-bar .list-items .item.active .link {
  color: var(--main-color);
}
.navigation-bar .list-items .item .link i {
  font-size: 1.6rem;
  transition: font-size 0.2s linear;
}
.navigation-bar .list-items .item.active .link i {
  font-size: 1.4rem;
}
iconify-icon{color: #fff;}
</style>
<div class="navone">

    <input type="checkbox" id="check">
    <label for="check">
      <i class="fas fa-bars" id="btn"></i>
      <i class="fas fa-times" id="cancel"></i>
    </label>
    <div class="sidebar">
    <header>My App</header>
  <ul>
<li id="scd"><a href="index.php"><i class="fas fa-home"></i>Accueuil</a></li>
<li id="scd"><a href="index.php"><i class="fas fa-binoculars"></i>Aller à la chasse</a></li>
<li id="scd"><a href="connexion.php"><i class="fas fa-key"></i>Se Connecter</a></li>
<li id="scd"><a href="#"><i class="fas fa-calendar"></i>Événements</a></li>
<li id="scd"><a href="inscription.php"><i class="fa fa-user-plus"></i>S'inscrire</a></li>
<li id="scd"><a href="#"><i class="fa fa-plus-circle"></i>Devenir Cacheur</a>
  <li id="scd"><a href="#"><iconify-icon icon='bi:chat-fill' width='25' height='26' style="margin-right: 16px;"></iconify-icon></i>Chat</a>
<li id="scd"><a href="leaderboard.php"><i class="fa fa-calendar-alt"></i>Tableau de score</a>

    
	<?php if(isset($_SESSION['pseudo'])) {echo ' 
	<li><a href="#"><i class="fas fa-user"></i>Profil</a></li>
		
	';}; ?>
<li><a href="#"><i class="far fa-envelope"></i>Contact</a></li>
</ul>
</div>
</li></li></ul></div></div>
<div class="navtwo"><div class="nav">
  <div class="nav-item active">
      <i class="material-icons home-icon">
          
      </i>
      <span class="nav-text"></span>
  </div>
  <div class="nav-item">
      <i class="material-icons favorite-icon">
          
      </i>
  </div>
  <div class="nav-item">
      <i class="material-icons search-icon">
          
      </i>
      <span class="nav-text"></span>
  </div>
  <div class="nav-item">
      <i class="material-icons person-icon">
          
      </i>
      <span class="nav-text"></span>
  </div>
</div>

<nav class="navigation-bar">
  <ul class="list-items">
    <span class="pointer"></span>
    <li class="item active">
      <a class="link" href="#">
        <i class=""><iconify-icon icon="mdi:home" width="35" height="45"></iconify-icon></i>
      </a>
    </li>
    <li class="item">
      <a class="link" href="#">
        <i class=""><iconify-icon icon="bi:chat-fill" width="30" height="40"></iconify-icon></i>
      </a>
    </li>
       <li class="item">
      <a class="link" href="#">
        <i class=""><iconify-icon icon="mdi:podium" width="35" height="45"></iconify-icon></i>
      </a>
    </li>
    <li class="item">
      <a class="link" href="#">
        <i class=""><iconify-icon icon="fa6-solid:magnifying-glass" width="50" height="60"></iconify-icon></i>
      </a>
    </li>
    <li class="item">
      <a class="link" href="#">
        <i class=""><iconify-icon icon="akar-icons:circle-plus" width="35" height="45"></iconify-icon></i>
      </a>
    </li>
    <li class="item">
      <a class="link" href="#">
        <i class=""><iconify-icon icon="mdi:user" width="35" height="45"></iconify-icon></i>
      </a>
    </li>
    <li class="item">
      <a class="link" href="#">
        <i class=""><iconify-icon icon="bx:mail-send" width="35" height="45"></iconify-icon></i>
      </a>
    </li>
  </ul>
</nav></div>
<script src="https://code.iconify.design/iconify-icon/1.0.0/iconify-icon.min.js"></script>
<script type="text/javascript">const navigation_items_elms = document.querySelectorAll(
  ".navigation-bar .list-items .item"
);
const navigation_pointer = document.querySelector(".navigation-bar .pointer");

navigation_items_elms.forEach((item, index) => {
  item.addEventListener("click", (e) => {
    e.preventDefault();
    navigation_items_elms.forEach((itm) => itm.classList.remove("active"));
    item.classList.add("active");

    const parentWidth = item.parentElement.clientWidth;
    const lefPercent = (parentWidth / navigation_items_elms.length) * index;
    navigation_pointer.style.left = lefPercent + "px";
  });
});
</script>
