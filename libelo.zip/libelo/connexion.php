<?php
session_start();

// Connexion BDD
$bdd = new PDO('mysql:host=127.0.0.1;dbname=libelo', 'root', '');

if (isset($_POST['formconnexion'])) {
   $mailconnect = htmlspecialchars($_POST['mailconnect']);
   $mdpconnect = htmlspecialchars($_POST['mdpconnect']);

   if (!empty($mailconnect) && !empty($mdpconnect)) {
      $requser = $bdd->prepare("SELECT * FROM membres WHERE mail = ? AND motdepasse = ?");
      $requser->execute(array($mailconnect, $mdpconnect));
      $userexist = $requser->rowCount();

      if ($userexist == 1) {
         $userinfo = $requser->fetch();
         $_SESSION['id'] = $userinfo['id'];
         $_SESSION['pseudo'] = $userinfo['pseudo'];
         $_SESSION['mail'] = $userinfo['mail'];
         $_SESSION['grade'] = $userinfo['grade'];
         header("Location: profil.php?id=".$_SESSION['id']);
         exit();
      } else {
         $erreur = "❌ Mauvais mail ou mot de passe.";
      }
   } else {
      $erreur = "⚠️ Tous les champs doivent être remplis.";
   }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
   <meta charset="UTF-8">
   <title>Connexion - Libelo</title>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <style>
      /* --- Reset & global --- */
      * { box-sizing: border-box; margin: 0; padding: 0; }
      body {
         font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
         background: linear-gradient(to right, #680027, #E86600);
         min-height: 100vh;
         display: flex;
         justify-content: center;
         align-items: center;
      }

      /* --- Card --- */
      .login-card {
         background: white;
         padding: 2.5rem;
         border-radius: 12px;
         box-shadow: 0 10px 25px rgba(0,0,0,0.15);
         width: 100%;
         max-width: 400px;
         text-align: center;
         animation: fadeIn 0.8s ease-in-out;
      }
      @keyframes fadeIn {
         from { opacity: 0; transform: translateY(-20px); }
         to { opacity: 1; transform: translateY(0); }
      }

      h2 {
         margin-bottom: 0.5rem;
         color: #333;
      }
      p.subtitle {
         margin-bottom: 2rem;
         color: #666;
         font-size: 0.95rem;
      }

      /* --- Inputs --- */
      input[type="email"], input[type="password"] {
         width: 100%;
         padding: 0.8rem;
         margin-bottom: 1.2rem;
         border: 1px solid #ddd;
         border-radius: 8px;
         font-size: 1rem;
         transition: all 0.2s;
      }
      input[type="email"]:focus, input[type="password"]:focus {
         outline: none;
         border-color: #4facfe;
         box-shadow: 0 0 0 3px rgba(79,172,254,0.2);
      }

      /* --- Button --- */
      input[type="submit"] {
         width: 100%;
         padding: 0.9rem;
         background: linear-gradient(90deg, #4facfe, #00f2fe);
         color: white;
         font-size: 1rem;
         border: none;
         border-radius: 8px;
         cursor: pointer;
         transition: transform 0.15s, box-shadow 0.15s;
      }
      input[type="submit"]:hover {
         transform: translateY(-2px);
         box-shadow: 0 5px 15px rgba(0,0,0,0.2);
      }

      /* --- Messages --- */
      .msg {
         margin-top: 1rem;
         font-size: 0.9rem;
         padding: 0.6rem;
         border-radius: 6px;
      }
      .msg.error { background: #ffe0e0; color: #c00; }
      .msg.success { background: #e0ffe8; color: #0a0; }

      /* --- Footer --- */
      .login-footer {
         margin-top: 1.5rem;
         font-size: 0.9rem;
         color: #555;
      }
      .login-footer a {
         color: #007bff;
         text-decoration: none;
         font-weight: 500;
      }
      .login-footer a:hover {
         text-decoration: underline;
      }
   </style>
</head>
<body>

   <div class="login-card">
      <h2>Connexion</h2>
      <p class="subtitle">Bienvenue sur Libelo 🚲</p>

      <form method="POST" action="">
         <input type="email" name="mailconnect" placeholder="Adresse e-mail" required>
         <input type="password" name="mdpconnect" placeholder="Mot de passe" required>
         <input type="submit" name="formconnexion" value="Se connecter">
      </form>

      <?php if(isset($erreur)): ?>
         <div class="msg error"><?= $erreur ?></div>
      <?php endif; ?>

      <div class="login-footer">
         Pas encore inscrit ? <a href="inscription.php">Créer un compte</a>
      </div>
   </div>

</body>
</html>
