<!DOCTYPE html>
<html>
<head>
  <title>Mon site web avec un code QR</title>
</head>
<body>
  <h1>Bienvenue sur mon site web !</h1>
  <p>Scannez ce code QR pour accéder à mon autre site web :</p>
  <div class="qrtiger"></div>
  <script type="text/javascript" src="https://media.qrtiger.com/js/qrtiger_widget.js" async></script>
  <script type="text/javascript">
    // Remplacez l'URL par celle de votre choix
    var qrtiger = new QRtigerWidget({
      url: "https://www.qrcode-tiger.com/fr",
      size: 200,
      color: "#000000",
      background: "#ffffff",
      logo: "https://www.qrcode-tiger.com/img/logo.png",
      logoWidth: 50,
      logoHeight: 50,
      logoX: 100,
      logoY: 100,
      logoBackground: false,
      logoBackgroundColor: "#ffffff",
      logoBorderRadius: 0,
      logoBorderWidth: 0,
      logoBorderColor: "#000000",
      eyeType: "frame1",
      eyeBallType: "ball1",
      eye1Color: "#000000",
      eye2Color: "#000000",
      eye3Color: "#000000",
      eyeBall1Color: "#000000",
      eyeBall2Color: "#000000",
      eyeBall3Color: "#000000",
      gradient: false,
      gradientType: "linear",
      gradientColor1: "#000000",
      gradientColor2: "#000000",
      gradientRotation: 0,
      bodyType: "square",
      bodyColor: "#000000",
      bodyScale: 100,
      frameName: "no-frame",
      frameText: "",
      frameX: 0,
      frameY: 0,
      frameWidth: 0,
      frameHeight: 0,
      frameColor: "#000000",
      frameTextSize: 0,
      frameTextMargin: 0,
      frameTextLineHeight: 0,
      frameTextAlign: "center",
      frameTextVAlign: "middle",
      frameTextBold: false,
      frameTextItalic: false,
      frameTextUnderline: false,
      frameTextFont: "Arial",
      frameTextColor: "#000000",
      frameImage: "",
      frameImageX: 0,
      frameImageY: 0,
      frameImageWidth: 0,
      frameImageHeight: 0,
      frameImageOpacity: 100,
      frameImageRotation: 0,
      frameImageHAlign: "center",
      frameImageVAlign: "middle",
      frameImageScale: 100,
      frameImageBackground: false,
      frameImageBackgroundColor: "#ffffff",
      frameImageBorderRadius: 0,
      frameImageBorderWidth: 0,
      frameImageBorderColor: "#000000",
      dotScale: 100,
      autoColor: false,
      autoColorDark: "#000000",
      autoColorLight: "#ffffff"
    });
    qrtiger.render();
  </script>
</body>
</html>
